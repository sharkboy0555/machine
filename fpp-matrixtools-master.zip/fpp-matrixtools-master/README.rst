fpp-matrixtools
===============

FPP Plugin for real-time manipulation of a matrix using the memory mapped
channel block interface.

Useful Links:

- `Falcon Christmas forums <http://falconchristmas.com>`_
- `Falcon Pi Player sub-forum <http://falconchristmas.com/forum/index.php/board,8.0.html>`_
- `Wiki <http://falconchristmas.com/wiki/index.php/Main_Page>`_

